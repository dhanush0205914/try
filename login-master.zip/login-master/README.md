# Java-Mysql-Simple-Login-Web-application

This is a simple demonstration project to showcase conatinerization of Java web application and Mysql database in docker and Kubernetes environment.


